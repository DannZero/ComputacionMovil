import UIKit

var video = 8
if video > 10 {
    print ("El video dura mucho!")
} else if video > 500 {
    print ("Esta DEMASIADO Largo!")
} else {
    print ("No está tan largo")
}

var hola = "Hola, buenos dias"
let dia = Date()

hola.hasPrefix("Hola")
hola.isEmpty
hola.removeAll()

var devices = ["iPad", "iMac", "iPhone", "iPod"]

devices[1]

let numeros = [6, 5, 4, 3, 2, 1]

print ("Tengo un \(devices[2]) \(numeros[1])")

let friends = ["Alan", "Brenda", "Mitzi", "Todos valen verga"]

for friend in friends {
    let sparklyFriend = "✨\(friend)✨"
    print ("Oye \(sparklyFriend), tambien vales verga 😉")
}

devices.append("macBook")

devices.insert("apple TV", at: 4)
devices += ["iPod nano", "earPods"]
devices.remove(at: 0)
devices.removeFirst()
devices.removeLast()

var flavours = ["Chocolate", "Vainilla", "Fresa"]
flavours[0] = "Frambuesa"
flavours[2] = "Limón"
print (flavours)
